"""Tests for published CSVs, independent of the build script's counters."""
import csv, hashlib, json, unittest
from pathlib import Path
from build_mujarrad_mutaaddi import health, FILE_FOR, VOCAB, TRANSITIVE, EXPECTED_LEMMA_BW, MASAQ_SHA256, bw_arabic
HERE=Path(__file__).parent

def records(path):
 with (HERE/path).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

class MujarradMutaaddiTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.main=records('00_All_Mujarrad_Mutaaddi.csv')
  cls.audit=json.loads((HERE/'09_Audit.json').read_text(encoding='utf-8'))
 def test_source_identity(self):
  self.assertEqual(self.audit['source']['MASAQ_sha256'],MASAQ_SHA256)
  self.assertEqual(self.audit['MASAQ_all_rows'],157677)
 def test_only_form_one(self):
  self.assertTrue(self.main)
  for r in self.main:
   self.assertEqual(r['Verb_Form'],'I / الثلاثي المجرد')
   self.assertNotRegex(r['QAC_Features'],r'\((?:II|III|IV|V|VI|VII|VIII|IX|X)\)')
 def test_only_reviewed_roots(self):
  self.assertTrue(all(r['QAC_RootBW'] in TRANSITIVE for r in self.main))
 def test_exact_lemma_gate(self):
  for r in self.main:
   self.assertEqual(r["QAC_Lemma"],bw_arabic(EXPECTED_LEMMA_BW[r["QAC_RootBW"]]))
 def test_transitivity_frame_not_assumed(self):
  self.assertTrue(all("OCCURRENCE_FRAME_NOT_INDEPENDENTLY_CERTIFIED" in r["Residual"] for r in self.main))
 def test_health(self):
  self.assertEqual(health('wEd'),('معتل','مثال'))
  self.assertEqual(health('rAy'),('معتل','ناقص + مهموز'))
  self.assertEqual(health('Ax*'),('صحيح','مهموز'))
  self.assertEqual(health('xlq'),('صحيح','سالم'))
 def test_categories_partition(self):
  combined=[]
  for (tense,voice),fname in FILE_FOR.items():
   group=records(fname)
   self.assertTrue(all((r['Verb_Tense'],r['Verb_Voice'])==(tense,voice) for r in group))
   combined+=group
   self.assertEqual(len(group),self.audit['counts_by_tense_voice'][f'{tense}:{voice}'])
  self.assertEqual(sorted(x['MASAQ_Source_Row'] for x in combined),sorted(x['MASAQ_Source_Row'] for x in self.main))
 def test_no_duplicate_masaq_rows(self):
  self.assertEqual(len(self.main),len({r['MASAQ_Source_Row'] for r in self.main}))
 def test_tag_and_voice_agreement(self):
  for r in self.main:self.assertEqual(VOCAB[r['Morph_tag']],(r['Verb_Tense'],r['Verb_Voice']))
 def test_counts(self):
  self.assertEqual(len(self.main),self.audit['selected_occurrences'])
  self.assertEqual(sum(self.audit['counts_by_health'].values()),len(self.main))
 def test_evidence_bound(self):
  self.assertTrue(all('PRELIMINARY' in r['Evidence_Rank'] for r in self.main))
  self.assertTrue(all('SENSE_AND_OCCURRENCE_FRAME_NOT_INDEPENDENTLY_CERTIFIED' in r['Residual'] for r in self.main))
 def test_exclusion_and_residual_nonoverlap(self):
  excluded=records('06_Excluded_Unreviewed_Form_I.csv')
  residuals=records('07_Alignment_Residuals.csv')
  self.assertEqual(len(excluded),self.audit['QAC_unreviewed_form_I_aligned'])
  self.assertEqual(len(residuals),self.audit['alignment_residual_count'])
  ids={r['MASAQ_Source_Row'] for r in self.main}
  self.assertFalse(ids & {r['MASAQ_Source_Row'] for r in excluded})
 def test_passive_disagreements_separate(self):
  rows=records('10_Passive_Review.csv')
  self.assertEqual(len(rows),self.audit['passive_review_count'])
  self.assertTrue(all(r['QAC_Voice']=='PASSIVE' and r['Status'].startswith('DEFERRED') for r in rows))
 def test_positive_health_and_form(self):
  self.assertEqual({r['Root_Health'] for r in self.main},{'صحيح','معتل'})
  self.assertTrue(all(r['QAC_Line'].isdigit() for r in self.main))

if __name__=='__main__':unittest.main()
