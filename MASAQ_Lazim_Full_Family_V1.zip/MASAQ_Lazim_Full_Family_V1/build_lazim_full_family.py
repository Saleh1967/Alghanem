#!/usr/bin/env python3
"""MASAQ + QAC bounded intransitive Form-I, augmented verbal nouns and nominal derivations.

This is a reproducible lexical hypothesis audit, not a valency or derivation certificate.
No source mutation or synthetic occurrence generation.
"""
from __future__ import annotations
import argparse, collections, csv, hashlib, json, re
from pathlib import Path

MASAQ_SHA='d43d2a813afbe0490254bb26623d6041ed352a273d333e731ddbcda3bd0b6f3a'
QAC_SHA='a1d12923815341face765083805d2148ed2d9f5cc3f7d6665219d887675d8c46'
B={'A':'ا','b':'ب','t':'ت','v':'ث','j':'ج','H':'ح','x':'خ','d':'د','*':'ذ','r':'ر','z':'ز','s':'س','$':'ش','S':'ص','D':'ض','T':'ط','Z':'ظ','E':'ع','g':'غ','f':'ف','q':'ق','k':'ك','l':'ل','m':'م','n':'ن','h':'ه','w':'و','y':'ي','p':'ة','Y':'ى','>':'أ','<':'إ','&':'ؤ','}':'ئ',"'":'ء','{':'ٱ','|':'آ','`':'ٰ','F':'ً','N':'ٌ','K':'ٍ','a':'َ','u':'ُ','i':'ِ','o':'ْ','~':'ّ','^':'ٓ','#':'ٔ','_':'ـ'}
LOC=re.compile(r'^\((\d+):(\d+):(\d+):(\d+)\)\t([^\t]+)\t([^\t]+)\t([^\n]+)')
ROMAN=re.compile(r'\(([IVX]+)\)')
MASDAR={'GERUND','GERUND_MEEM','GERUND_INSTANT','GERUND_PROFESSION','GERUND_STATE'}
DERIV={'NOUN_ACTIVE_PART','NOUN_PASSIVE_PART','NOUN_TIME_PLACE','NOUN_INSTRUMENT','ADJ_QUALIT','ADJ_INTENS','ADJ_COMP'}
NOUN=MASDAR|DERIV|{'NOUN_ABSTRACT','NOUN_CONCRETE','NOUN_PROP'}
VOCAB={'PV':('PAST','ACTIVE'),'IV':('IMPERFECT','ACTIVE'),'CV':('IMPERATIVE','ACTIVE'),'PV_PASS':('PAST','PASSIVE'),'IV_PASS':('IMPERFECT','PASSIVE')}
# Explicit *preliminary* lexical selection of independently recognizable intransitive augmented lexemes.
# The code does not certify that their every Quranic occurrence has an independently established valency frame.
AUGMENTED_LEXEMES={
 ('kbr','V'):{'hint':'تَكَبَّرَ','forms':{'yatakab~aru'}},
 ('kbr','X'):{'hint':'اِسْتَكْبَرَ','forms':{'{sotakobara'}},
 ('qwm','X'):{'hint':'اِسْتَقَامَ','forms':{'{sotaqa`mu'}},
 ('nzl','V'):{'hint':'تَنَزَّلَ','forms':{'tanaz~alato'}},
 ('sqT','III'):{'hint':'تَسَاقَطَ [يلزم تحقيق وسم الصيغة]','forms':set()},
}
V_FIELDS=['Source_MASAQ_Row','Sura_No','Verse_No','Column5','Segment_No','MASAQ_Word','MASAQ_Segment','MASAQ_Tag','QAC_Segment','QAC_Lemma_BW','QAC_Lemma_Arabic','QAC_RootBW','Root_Arabic','Form','Tense','Voice','Root_Health','Root_Health_Detail','Origin_Form_I_Past','Origin_Reference','Augmented_Lexical_Hint','Transitivity_Status','Source_Agreement','Relationship','Evidence_Rank','Residual','QAC_Features','QAC_Line','QAC_URL']
N_FIELDS=V_FIELDS+['Nominal_Category','Masdar_Status','Participle_Status','Derivation_Proof_Status']
REVIEW_FIELDS=['Sura_No','Verse_No','Column5','Segment_No','MASAQ_Row','MASAQ_Word','QAC_Word','MASAQ_Tag','QAC_Segment','QAC_RootBW','Form','QAC_Lemma_BW','QAC_Features','QAC_Line','Reason']
FAMILY_FIELDS=['RootBW','RootArabic','OriginPast','OriginPastCount','Form','AugmentedLexeme','FamilyCategory','LexemeBW','LexemeArabic','Witnesses','FirstLocation','Status','DirectDerivationProof']

def readcsv(path):
 with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def writecsv(path,fields,records):
 with path.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(records)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def arabic(t):return ''.join(B.get(ch,ch) for ch in t)
def bare(t):
 import unicodedata
 t=''.join(x for x in unicodedata.normalize('NFC',t.replace('ٰ','ا')) if unicodedata.category(x)!='Mn' and x not in 'ـ۞۩[]')
 return t.translate(str.maketrans({'أ':'ا','إ':'ا','آ':'ا','ٱ':'ا','ى':'ي','ؤ':'و','ئ':'ي'}))
def feature(s,key):
 m=re.search(r'(?:^|\|)'+re.escape(key)+r':([^|]+)',s);return m.group(1) if m else ''
def health(root):
 if len(root)!=3:return ('UNRESOLVED','NON_TRILITERAL')
 weak=[i for i,x in enumerate(root) if x in 'wyY']
 if weak:return ('معتل', ('مثال','أجوف','ناقص')[weak[0]] if len(weak)==1 else ('لفيف مفروق' if weak==[0,2] else 'لفيف مقرون'))
 extra=['مهموز'] if any(x in "A><&}'" for x in root) else []
 if root[1]==root[2]:extra.append('مضعف')
 return ('صحيح',' + '.join(extra) if extra else 'سالم')
def tense(f):return 'PAST' if '|PERF' in f else 'IMPERFECT' if '|IMPF' in f else 'IMPERATIVE' if '|IMPV' in f else 'UNKNOWN'
def voice(f):return 'PASSIVE' if '|PASS' in f else 'ACTIVE'
def loc(k):return ':'.join(map(str,k))

def build(masaq,qac,form_i_verbs,form_i_nominals,passive_review,out,strict=True):
 out.mkdir(parents=True,exist_ok=True)
 sources={'MASAQ':masaq,'QAC':qac,'FORM_I_VERBS':form_i_verbs,'FORM_I_NOMINALS':form_i_nominals,'PASSIVE_REVIEW':passive_review}
 hashes={name:sha(p) for name,p in sources.items()}
 if strict and (hashes['MASAQ']!=MASAQ_SHA or masaq.stat().st_size!=20302008):raise ValueError('MASAQ_REFERENCE_BYTES_MISMATCH')
 if strict and hashes['QAC']!=QAC_SHA:raise ValueError('QAC_REFERENCE_BYTES_MISMATCH')
 origin=readcsv(form_i_verbs); oldn=readcsv(form_i_nominals); oldp=readcsv(passive_review)
 if any(x['Verb_Form']!='I / الثلاثي المجرد' for x in origin):raise ValueError('NON_FORM_I_ORIGIN')
 roots=collections.defaultdict(list)
 for x in origin:
  if x['Verb_Tense']=='PAST' and x['Verb_Voice']=='ACTIVE':roots[x['QAC_RootBW']].append(x)
 unanchored_form_I=[x for x in origin if x['QAC_RootBW'] not in roots]
 origin_ids={(x['Sura_No'],x['Verse_No'],x['Column5'],x['MASAQ_Source_Row']) for x in origin}
 oldn=[x for x in oldn if x['QAC_RootBW'] in roots]
 mwords=collections.defaultdict(list)
 with masaq.open(encoding='utf-8-sig',newline='') as f:
  rr=csv.DictReader(f)
  if len(rr.fieldnames)!=19 or not {'Column5','Morph_tag','Morph_type','Word'}.issubset(rr.fieldnames):raise ValueError('MASAQ_SCHEMA_MISMATCH')
  count=0
  for count,r in enumerate(rr,1):
   r['MASAQ_Source_Row']=str(count)
   if r['Morph_type']=='Stem' and r['Morph_tag'] in NOUN|set(VOCAB):
    mwords[(int(r['Sura_No']),int(r['Verse_No']),int(r['Column5']))].append(r)
 qwords=collections.defaultdict(lambda:{'parts':[],'targets':[]})
 q_target=collections.Counter()
 with qac.open(encoding='utf-8-sig') as f:
  for line_num,line in enumerate(f,1):
   m=LOC.match(line)
   if not m:continue
   su,ay,wo,sg,surface,tag,feats=m.groups();root=feature(feats,'ROOT')
   if root not in roots or not feats.startswith('STEM|') or tag not in {'V','N','ADJ'}:continue
   formm=ROMAN.search(feats)
   if not formm or formm.group(1)=='I':continue
   form=formm.group(1);type_='VERB' if tag=='V' else 'VN' if '|VN' in feats else 'PARTICIPLE' if '|PCPL' in feats else 'OTHER_NOUN'
   entry={'segment':int(sg),'surface':surface,'tag':tag,'feats':feats,'root':root,'form':form,'type':type_,'lemma':feature(feats,'LEM'),'line':line_num}
   qwords[(int(su),int(ay),int(wo))]['targets'].append(entry)
   q_target[(form,type_)]+=1
 with qac.open(encoding='utf-8-sig') as f:
  for line in f:
   m=LOC.match(line)
   if m:
    su,ay,wo,sg,surface,tag,feats=m.groups();k=(int(su),int(ay),int(wo))
    if k in qwords:qwords[k]['parts'].append((int(sg),surface))
 outputs=collections.defaultdict(list); reviews=[]; seen=set(); excluded_transitive=[]; reviewed=collections.Counter()
 # Manually bounded intransitive augmented lexeme pairs; all other same-root augmented forms are excluded from the accepted tables.
 for key,qword in sorted(qwords.items()):
  qfull=arabic(''.join(p for _,p in sorted(qword['parts'])))
  mlist=mwords.get(key,[])
  for v in qword['targets']:
   root,form=v['root'],v['form']; lemma=v['lemma'];kind=v['type']
   manual=AUGMENTED_LEXEMES.get((root,form))
   if kind=='VERB' and manual is not None and manual['forms'] and lemma not in manual['forms']:
    manual=None
   # All candidate (root,form) pairs without a preliminary lexical hint remain explicitly outside accepted intransitive results.
   if manual is None:
    excluded_transitive.append(dict(Sura_No=key[0],Verse_No=key[1],Column5=key[2],Segment_No=v['segment'],RootBW=root,RootArabic=roots[root][0]['Root_Arabic'],Form=form,QAC_Lemma=arabic(lemma),QAC_Tag=v['tag'],QAC_Features=v['feats'],QAC_Line=v['line'],Reason='NOT_REVIEWED_AS_INTRANSITIVE__MAY_BE_TRANSITIVE_OR_AMBIGUOUS'))
    continue
   if (root,form)==('sqT','III'):
    excluded_transitive.append(dict(Sura_No=key[0],Verse_No=key[1],Column5=key[2],Segment_No=v['segment'],RootBW=root,RootArabic=roots[root][0]['Root_Arabic'],Form=form,QAC_Lemma=arabic(lemma),QAC_Tag=v['tag'],QAC_Features=v['feats'],QAC_Line=v['line'],Reason='QAC_FORM_III_INTRANSITIVITY_REQUIRES_INDEPENDENT_ANALYSIS'))
    continue
   if not mlist or bare(mlist[0]['Word'])!=bare(qfull):
    reviews.append(dict(Sura_No=key[0],Verse_No=key[1],Column5=key[2],Segment_No=v['segment'],MASAQ_Word=mlist[0]['Word'] if mlist else '',QAC_Word=qfull,QAC_Segment=arabic(v['surface']),QAC_RootBW=root,Form=form,QAC_Lemma_BW=lemma,QAC_Features=v['feats'],QAC_Line=v['line'],Reason='NO_MASAQ_WORD' if not mlist else 'WORD_OR_ORTHOGRAPHY_MISMATCH'));continue
   if kind=='VERB':eligible=[x for x in mlist if x['Morph_tag'] in VOCAB and VOCAB[x['Morph_tag']]==(tense(v['feats']),voice(v['feats']))]
   else:eligible=[x for x in mlist if x['Morph_tag'] in NOUN]
   if len(eligible)>1:
    mm=[r for r in eligible if bare(r['Segmented_Word'])==bare(arabic(v['surface']))]
    if len(mm)==1:eligible=mm
   if len(eligible)!=1:
    reviews.append(dict(Sura_No=key[0],Verse_No=key[1],Column5=key[2],Segment_No=v['segment'],MASAQ_Word=mlist[0]['Word'],QAC_Word=qfull,QAC_Segment=arabic(v['surface']),MASAQ_Tag=';'.join(x['Morph_tag'] for x in eligible),QAC_RootBW=root,Form=form,QAC_Lemma_BW=lemma,QAC_Features=v['feats'],QAC_Line=v['line'],Reason='UNIQUE_COMPATIBLE_MASAQ_STEM_NOT_ESTABLISHED'));continue
   m=eligible[0];uid=(m['MASAQ_Source_Row'],v['line'])
   if uid in seen:raise ValueError('DUPLICATE_WITNESS')
   seen.add(uid)
   h,hd=health(root);anchor=roots[root];p=anchor[0]
   r=dict(Source_MASAQ_Row=m['MASAQ_Source_Row'],Sura_No=key[0],Verse_No=key[1],Column5=key[2],Segment_No=v['segment'],MASAQ_Word=m['Word'],MASAQ_Segment=m['Segmented_Word'],MASAQ_Tag=m['Morph_tag'],QAC_Segment=arabic(v['surface']),QAC_Lemma_BW=lemma,QAC_Lemma_Arabic=arabic(lemma),QAC_RootBW=root,Root_Arabic=p['Root_Arabic'],Form=form,Tense=tense(v['feats']) if kind=='VERB' else '',Voice=voice(v['feats']) if kind=='VERB' else '',Root_Health=h,Root_Health_Detail=hd,Origin_Form_I_Past=p['Lexical_Intransitive_Anchor'],Origin_Reference=loc((p['Sura_No'],p['Verse_No'],p['Column5'])),Augmented_Lexical_Hint=manual['hint'],Transitivity_Status='PRELIMINARY_LEXICAL_INTRANSITIVE__NOT_CONTEXT_VERIFIED',Source_Agreement='MASAQ_QAC_ALIGNED',Relationship='SAME_ROOT_AND_FORM__DIRECT_DERIVATION_NOT_PROVEN',Evidence_Rank='ATTESTED_OCCURRENCE__PRELIMINARY_VALENCY',Residual='SENSE_SPECIFIC_TRANSITIVITY_NOT_INDEPENDENTLY_CERTIFIED',QAC_Features=v['feats'],QAC_Line=v['line'],QAC_URL=f'https://corpus.quran.com/wordmorphology.jsp?location=({key[0]}:{key[1]}:{key[2]}:{v["segment"]})')
   if kind=='VERB':
    cat='AUGMENTED_VERB';r['Relationship']='FORM_I_ORIGIN__SAME_ROOT_AUGMENTED_VERB';
   elif kind=='VN':
    if m['Morph_tag'] in MASDAR:
     cat='AUGMENTED_MASDAR_AGREED';r.update(Nominal_Category='AUGMENTED_MASDAR',Masdar_Status='QAC_VN_AND_MASAQ_GERUND__FORM_MATCH',Derivation_Proof_Status='NOT_PROVEN')
    else:
     cat='AUGMENTED_MASDAR_REVIEW';r.update(Nominal_Category='MASDAR_REVIEW',Masdar_Status='QAC_VN_ONLY__MASAQ_OTHER_NOUN',Derivation_Proof_Status='NOT_PROVEN')
   elif kind=='PARTICIPLE':
    pk='ACTIVE' if '|ACT|PCPL' in v['feats'] else 'PASSIVE' if '|PASS|PCPL' in v['feats'] else 'UNKNOWN'
    if (pk=='ACTIVE' and m['Morph_tag']=='NOUN_ACTIVE_PART') or (pk=='PASSIVE' and m['Morph_tag']=='NOUN_PASSIVE_PART'):
     cat='AUGMENTED_PARTICIPLE_AGREED';r.update(Nominal_Category=pk+'_PARTICIPLE',Participle_Status='QAC_MASAQ_AGREE',Derivation_Proof_Status='NOT_PROVEN')
    else:
     cat='AUGMENTED_PARTICIPLE_REVIEW';r.update(Nominal_Category=pk+'_PARTICIPLE_REVIEW',Participle_Status='QAC_MASAQ_PARTICIPLE_DISAGREE',Derivation_Proof_Status='NOT_PROVEN')
   else:
    cat='AUGMENTED_OTHER_NOUN_REVIEW';r.update(Nominal_Category='OTHER_NOUN',Derivation_Proof_Status='NOT_PROVEN',Residual='QAC_DOES_NOT_CERTIFY_AUGMENTED_DERIVATIVE_CLASS')
   r['Category']=cat;outputs[cat].append(r)
 for rows in outputs.values():rows.sort(key=lambda x:int(x['Source_MASAQ_Row']))
 # Copy previous Form-I records with explicit voice and tense, leaving passive review outside the accepted counts.
 origin.sort(key=lambda x:int(x['MASAQ_Source_Row']))
 writecsv(out/'00_Form_I_Lazim_Verbs.csv',list(origin[0]) if origin else ['RootBW'],origin)
 writecsv(out/'07_Form_I_Without_Past_Anchor.csv',list(origin[0]) if origin else ['RootBW'],unanchored_form_I)
 kinds={('PAST','ACTIVE'):'01_Form_I_Past_Active.csv',('IMPERFECT','ACTIVE'):'02_Form_I_Imperfect_Active.csv',('IMPERATIVE','ACTIVE'):'03_Form_I_Imperative.csv',('PAST','PASSIVE'):'04_Form_I_Past_Passive.csv',('IMPERFECT','PASSIVE'):'05_Form_I_Imperfect_Passive.csv'}
 for (t,v),name in kinds.items():writecsv(out/name,list(origin[0]) if origin else ['RootBW'],[r for r in origin if r['Verb_Tense']==t and r['Verb_Voice']==v])
 writecsv(out/'06_Form_I_Passive_Review.csv',list(oldp[0]) if oldp else ['Sura_No','Verse_No','Column5','Status'],oldp)
 category_files={'AUGMENTED_VERB':'10_Augmented_Lazim_Verbs_Preliminary.csv','AUGMENTED_MASDAR_AGREED':'11_Augmented_Masdars_Two_Source.csv','AUGMENTED_MASDAR_REVIEW':'12_Augmented_Masdars_Review.csv','AUGMENTED_PARTICIPLE_AGREED':'13_Augmented_Nominal_Derivatives_Two_Source.csv','AUGMENTED_PARTICIPLE_REVIEW':'14_Augmented_Nominal_Derivatives_Review.csv','AUGMENTED_OTHER_NOUN_REVIEW':'15_Other_Augmented_Nominals_Review.csv'}
 for cat,name in category_files.items():writecsv(out/name,N_FIELDS if cat!='AUGMENTED_VERB' else V_FIELDS,outputs[cat])
 writecsv(out/'16_Excluded_Augmented_Unreviewed_or_Transitive.csv',['Sura_No','Verse_No','Column5','Segment_No','RootBW','RootArabic','Form','QAC_Lemma','QAC_Tag','QAC_Features','QAC_Line','Reason'],excluded_transitive)
 writecsv(out/'17_Alignment_Residuals.csv',REVIEW_FIELDS,reviews)
 origin_categories={'MASDAR_STRICT':'20_Form_I_Masdars_Two_Source.csv','MASDAR_CANDIDATE':'21_Form_I_Masdars_Review.csv','ACTIVE_PARTICIPLE':'22_Form_I_Active_Participles.csv','PASSIVE_PARTICIPLE':'23_Form_I_Passive_Participles.csv','OTHER_DERIVATIVE_CANDIDATE':'24_Form_I_Other_Derivative_Candidates.csv','SAME_ROOT_NOUN':'25_Same_Root_Nouns_Not_Proven_Derivatives.csv','EXCLUDED_AUGMENTED_MASDAR':'26_Previous_Augmented_Masdar_Exclusion.csv','EXCLUDED_AUGMENTED_DERIVATIVE':'27_Previous_Augmented_Derivative_Exclusion.csv'}
 for cat,name in origin_categories.items():writecsv(out/name,list(oldn[0]) if oldn else ['RootBW'],[r for r in oldn if r['Family_Class']==cat])
 all_aug=[r for cat in category_files for r in outputs[cat]]
 groups=collections.defaultdict(list)
 for r in all_aug:groups[(r['QAC_RootBW'],r['Form'],r['QAC_Lemma_BW'],r['Category'])].append(r)
 for r in oldn:groups[(r['QAC_RootBW'],'I',r['QAC_Lemma_BW'],r['Family_Class'])].append(r)
 fam=[]
 for (root,form,lemma,cat),rr in sorted(groups.items()):
  e=rr[0];a=roots[root][0];first=(e['Sura_No'],e['Verse_No'],e['Column5'])
  fam.append(dict(RootBW=root,RootArabic=a['Root_Arabic'],OriginPast=a['Lexical_Intransitive_Anchor'],OriginPastCount=len(roots[root]),Form=form,AugmentedLexeme=e.get('Augmented_Lexical_Hint',''),FamilyCategory=cat,LexemeBW=lemma,LexemeArabic=e.get('QAC_Lemma_Arabic',e.get('QAC_Lemma_Arabic','')),Witnesses=len(rr),FirstLocation=loc(first),Status=e.get('Transitivity_Status','FORM_I_ROOT_LINK_ONLY'),DirectDerivationProof='NOT_PROVEN'))
 writecsv(out/'30_Family_Index.csv',FAMILY_FIELDS,fam)
 audit={'status':'BOUNDED_FORM_I_LAZIM_AND_PRELIMINARY_AUGMENTED_INTRANSITIVE_FAMILIES__NOT_COMPLETE','source_sha256':hashes,'source_masaq_rows':count,'form_I_verb_occurrences':len(origin),'form_I_roots':len(roots),'form_I_other_roots_without_past':sorted(set(x['QAC_RootBW'] for x in unanchored_form_I)),'form_I_other_occurrences_without_past':len(unanchored_form_I),'form_I_by_tense_voice':{f'{t}_{v}':sum(1 for r in origin if r['Verb_Tense']==t and r['Verb_Voice']==v) for t,v in kinds},'form_I_passive_review':len(oldp),'form_I_nominal_links_total':len(oldn),'form_I_nominal_categories':dict(collections.Counter(r['Family_Class'] for r in oldn)),'augmented_candidates_by_qac':{f'{form}_{kind}':n for (form,kind),n in sorted(q_target.items())},'augmented_preliminary_intransitive_categories':{c:len(outputs[c]) for c in category_files},'augmented_preliminary_total':len(all_aug),'augmented_unique_lexeme_categories':len({(r['QAC_RootBW'],r['Form'],r['QAC_Lemma_BW'],r['Category']) for r in all_aug}),'augmented_unreviewed_or_transitive_excluded':len(excluded_transitive),'alignment_residuals':len(reviews),'families':len(fam),'augmented_lexeme_hints':{root+':'+form:v['hint'] for (root,form),v in AUGMENTED_LEXEMES.items()},'independent_valency_certificates':0,'independent_direct_derivation_certificates':0,'source_changed':False,'limitations':['Intransitive Form I origin is an earlier 20-root/87-past-observation pilot, not an exhaustive lexicon.','Augmented intransitivity is a lexical hypothesis requiring contextual direct-object audits.','Form-I and augmented verbal nouns require exact matching FORM features; same root is insufficient for direct derivation.','Form-I passive QAC/MASAQ disputed cases are not promoted to accepted witnesses.','Additional augmented lexemes excluded if valency not manually reviewed; exclusion is not a claim they are all transitive.','QAC and MASAQ source licenses/attributions must be honored.']}
 (out/'31_Audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 return audit

def main():
 ap=argparse.ArgumentParser()
 for opt in ('masaq','qac','form-i-verbs','form-i-nominals','passive-review','out'):ap.add_argument('--'+opt,type=Path,required=True)
 ap.add_argument('--no-strict',action='store_true'); a=ap.parse_args()
 audit=build(a.masaq,a.qac,a.form_i_verbs,a.form_i_nominals,a.passive_review,a.out,not a.no_strict)
 print(json.dumps({k:audit[k] for k in ('form_I_roots','form_I_verb_occurrences','form_I_nominal_links_total','augmented_preliminary_intransitive_categories','augmented_preliminary_total','augmented_unreviewed_or_transitive_excluded','alignment_residuals')},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
