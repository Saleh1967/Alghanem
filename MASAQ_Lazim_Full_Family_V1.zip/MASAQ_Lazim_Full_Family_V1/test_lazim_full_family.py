"""Bounded regression tests for exact-source MASAQ intransitive families."""
import csv, hashlib, json, pathlib, re, unittest
P=pathlib.Path(__file__).resolve().parent

def records(name):
 with (P/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
class TestLazimFamily(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.a=json.loads((P/'31_Audit.json').read_text(encoding='utf-8'))
  cls.v=records('00_Form_I_Lazim_Verbs.csv')
  cls.aug=records('10_Augmented_Lazim_Verbs_Preliminary.csv')
  cls.masdar=records('11_Augmented_Masdars_Two_Source.csv')
  cls.deriv=records('13_Augmented_Nominal_Derivatives_Two_Source.csv')
 def test_source_fingerprint_contract(self):
  self.assertEqual(self.a['source_sha256']['MASAQ'],'d43d2a813afbe0490254bb26623d6041ed352a273d333e731ddbcda3bd0b6f3a')
  self.assertEqual(self.a['source_sha256']['QAC'],'a1d12923815341face765083805d2148ed2d9f5cc3f7d6665219d887675d8c46')
 def test_existing_form_i_preserved(self):
  self.assertEqual(len(self.v),328)
  self.assertTrue(all(r['Verb_Form']=='I / الثلاثي المجرد' for r in self.v))
 def test_past_anchor_gate(self):
  self.assertEqual(self.a['form_I_roots'],20)
  self.assertEqual(len(records('07_Form_I_Without_Past_Anchor.csv')),11)
  self.assertEqual(self.a['form_I_other_roots_without_past'],['Hyy','rkD','rkE'])
 def test_tense_splits_disjoint_and_complete(self):
  split=['01_Form_I_Past_Active.csv','02_Form_I_Imperfect_Active.csv','03_Form_I_Imperative.csv','04_Form_I_Past_Passive.csv','05_Form_I_Imperfect_Passive.csv']
  rows=sum((records(x) for x in split),[])
  self.assertEqual({r['MASAQ_Source_Row'] for r in rows},{r['MASAQ_Source_Row'] for r in self.v})
  self.assertEqual(len(rows),len(self.v))
 def test_disputed_passive_not_promoted(self):
  self.assertEqual(len(records('04_Form_I_Past_Passive.csv')),0)
  self.assertEqual(len(records('05_Form_I_Imperfect_Passive.csv')),0)
  self.assertEqual(len(records('06_Form_I_Passive_Review.csv')),7)
 def test_original_nominal_partition(self):
  fs=[f'{i:02d}_' for i in range(20,28)]
  rows=sum((records(next(p.name for p in P.glob(prefix+'*.csv'))) for prefix in fs),[])
  self.assertEqual(len(rows),1154)
  self.assertEqual(len({(r['MASAQ_Source_Row'],r['QAC_Line']) for r in rows}),len(rows))
 def test_augmented_lexeme_form_and_voice(self):
  self.assertEqual(len(self.aug),33)
  for r in self.aug:
   self.assertIn((r['QAC_RootBW'],r['Form']),{('kbr','V'),('kbr','X'),('qwm','X'),('nzl','V')})
   self.assertRegex(r['QAC_Features'],r'\('+r['Form']+r'\)')
   self.assertIn(r['MASAQ_Tag'],{'PV','IV','CV','PV_PASS','IV_PASS'})
   self.assertEqual(r['Transitivity_Status'],'PRELIMINARY_LEXICAL_INTRANSITIVE__NOT_CONTEXT_VERIFIED')
 def test_augmented_masdar_source_agreement(self):
  self.assertEqual(len(self.masdar),2)
  self.assertTrue(all(r['MASAQ_Tag'].startswith('GERUND') and '|VN' in r['QAC_Features'] and r['Form']=='X' for r in self.masdar))
 def test_nominal_participle_two_source(self):
  self.assertEqual(len(self.deriv),50)
  for r in self.deriv:
   self.assertIn('|PCPL',r['QAC_Features'])
   self.assertEqual(r['MASAQ_Tag'],'NOUN_ACTIVE_PART')
 def test_no_unreviewed_promotion(self):
  self.assertEqual(len(records('16_Excluded_Augmented_Unreviewed_or_Transitive.csv')),615)
  self.assertEqual(len(records('17_Alignment_Residuals.csv')),26)
 def test_no_derivation_or_valency_certificate(self):
  self.assertEqual(self.a['independent_direct_derivation_certificates'],0)
  self.assertEqual(self.a['independent_valency_certificates'],0)
  self.assertTrue(all(r['Relationship'].endswith('NOT_PROVEN') or 'SAME_ROOT_AUGMENTED_VERB' in r['Relationship'] for r in self.masdar+self.deriv+self.aug))
 def test_family_index_counts(self):
  self.assertEqual(len(records('30_Family_Index.csv')),self.a['families'])
  self.assertEqual(self.a['augmented_preliminary_total'],len(self.masdar)+len(self.deriv)+len(self.aug))
if __name__=='__main__': unittest.main()
