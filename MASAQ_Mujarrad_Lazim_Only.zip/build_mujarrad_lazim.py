#!/usr/bin/env python3
"""Evidence-bounded Quranic MASAQ form-I / lexically-intransitive extraction.

This tool makes a derived file; it does not mutate source MASAQ. Intransitivity
is a preliminary lexeme-level whitelist and not inferred from bare roots.
"""
from __future__ import annotations
import argparse, collections, csv, hashlib, json, re, unicodedata
from pathlib import Path

MASAQ_SHA256='d43d2a813afbe0490254bb26623d6041ed352a273d333e731ddbcda3bd0b6f3a'
MASAQ_LENGTH=20302008
QAC_SHA256='a1d12923815341face765083805d2148ed2d9f5cc3f7d6665219d887675d8c46'
B={'A':'ا','b':'ب','t':'ت','v':'ث','j':'ج','H':'ح','x':'خ','d':'د','*':'ذ','r':'ر','z':'ز','s':'س','$':'ش','S':'ص','D':'ض','T':'ط','Z':'ظ','E':'ع','g':'غ','f':'ف','q':'ق','k':'ك','l':'m','m':'م','n':'ن','h':'ه','w':'و','y':'ي','p':'ة','Y':'ى','>':'أ','<':'إ','&':'ؤ','}':'ئ',"'":'ء','{':'ٱ','|':'آ','`':'ٰ','F':'ً','N':'ٌ','K':'ٍ','a':'َ','u':'ُ','i':'ِ','o':'ْ','~':'ّ','^':'ٓ','#':'ٔ','_':'ـ'}
B['l']='ل'
LOC=re.compile(r'^\((\d+):(\d+):(\d+):(\d+)\)\t([^\t]+)\t([^\t]+)\t([^\n]+)')
VOCAB={'PV':('PAST','ACTIVE'),'IV':('IMPERFECT','ACTIVE'),'CV':('IMPERATIVE','ACTIVE'),'PV_PASS':('PAST','PASSIVE'),'IV_PASS':('IMPERFECT','PASSIVE')}
# Preliminary lexical entry review; multiple other roots may also be intransitive.
# No claim that absence from this map means transitivity, or that every occurrence
# of these roots is intransitive in every sense. The attested lemma is retained.
INTRANSITIVE={
 'xrj':('خرج','خَرَجَ'), 'qwm':('قام','قَامَ'), 'mwt':('مات','مَاتَ'),
 'frH':('فرح','فَرِحَ'),'sjd':('سجد','سَجَدَ'),'rkE':('ركع','رَكَعَ'),
 'qEd':('قعد','قَعَدَ'),'mrD':('مرض','مَرِضَ'),'kbr':('كبر','كَبُرَ'),
 'Hsn':('حسن','حَسُنَ'),'wqE':('وقع','وَقَعَ'),'nzl':('نزل','نَزَلَ'),
 'grb':('غرب','غَرَبَ'),'SlH':('صلح','صَلَحَ'),'bky':('بكى','بَكَى'),
 'Hyy':('حيي','حَيِيَ'),'Ejb':('عجب','عَجِبَ'),'m$y':('مشى','مَشَى'),
 'jry':('جرى','جَرَى'),'sEy':('سعى','سَعَى'),'rkD':('ركض','رَكَضَ'),
 'frr':('فرّ','فَرَّ'),'sqT':('سقط','سَقَطَ'),
}
# Root-lexeme exceptions: an attested morphological stem must still match the
# specified lexeme. This avoids transferring a whitelist decision to other lemmas.
# The strings here are evidence labels, NOT an independent certified dictionary.
FILE_FOR={('PAST','ACTIVE'):'01_Past_Active.csv',('IMPERFECT','ACTIVE'):'02_Imperfect_Active.csv',('IMPERATIVE','ACTIVE'):'03_Imperative.csv',('PAST','PASSIVE'):'04_Passive_Past.csv',('IMPERFECT','PASSIVE'):'05_Passive_Imperfect.csv'}
FIELDS=['MASAQ_Source_Row','ID','Sura_No','Verse_No','Column5','Word_No','Word','Without_Diacritics','Segmented_Word','Morph_tag','Morph_type','Case_Mood','Syntactic_Role','QAC_Form','QAC_Lemma','QAC_RootBW','Root_Arabic','Lexical_Intransitive_Anchor','Verb_Form','Verb_Tense','Verb_Voice','Root_Health','Root_Health_Detail','QAC_Features','QAC_Line','Evidence_Rank','Residual','QAC_URL']
EXFIELDS=['Sura_No','Verse_No','Column5','MASAQ_Source_Row','Word','Segmented_Word','Morph_tag','QAC_RootBW','QAC_Lemma','QAC_Features','Exclusion_Reason','QAC_Line']
REFIELDS=['Sura_No','Verse_No','Column5','MASAQ_Source_Row','MASAQ_Word','QAC_Word','MASAQ_Stem','QAC_Stem','RootBW','Reason','QAC_Line']

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def bw_arabic(t):return ''.join(B.get(x,x) for x in t)
def bare(t):
 t=t.replace('ٰ','ا').rstrip('@,.;:[]')
 t=''.join(c for c in unicodedata.normalize('NFC',t) if unicodedata.category(c)!='Mn' and c not in 'ـ۞۩')
 return t.translate(str.maketrans({'أ':'ا','إ':'ا','آ':'ا','ٱ':'ا','ى':'ي','ؤ':'و','ئ':'ي'}))
def feature_value(s,token):
 m=re.search(r'(?:^|\|)'+re.escape(token)+r':([^|]+)',s)
 return m.group(1) if m else ''
def verb_info(features):
 if '|PERF' in features:return 'PAST'
 if '|IMPF' in features:return 'IMPERFECT'
 if '|IMPV' in features:return 'IMPERATIVE'
 return ''
def health(root):
 if len(root)!=3 or not all(x in B for x in root):return ('UNRESOLVED','NON_CANONICAL_TRILITERAL_ROOT')
 weak=[i for i,x in enumerate(root) if x in 'wyY']
 hamz='A><&}' + "'"
 if not weak:
  extra=[]
  if any(x in hamz for x in root):extra.append('مهموز')
  if root[1]==root[2]:extra.append('مضعف')
  return ('صحيح',' + '.join(extra) if extra else 'سالم')
 if len(weak)==1:
  subtype=('مثال','أجوف','ناقص')[weak[0]]
 elif len(weak)==2:subtype='لفيف مفروق' if weak==[0,2] else 'لفيف مقرون'
 else:subtype='متعدد الاعتلال'
 if any(x in hamz for x in root):subtype+=' + مهموز'
 return ('معتل',subtype)
def load_qac(path):
 grouped=collections.defaultdict(lambda:{'parts':[],'verbs':[]})
 examined=0
 with path.open(encoding='utf-8-sig') as f:
  for n,line in enumerate(f,1):
   m=LOC.match(line)
   if not m:continue
   su,ay,wo,seg,form,tag,feat=m.groups();key=(int(su),int(ay),int(wo))
   v=grouped[key];v['parts'].append((int(seg),form))
   if tag!='V' or not feat.startswith('STEM|') or '|POS:V' not in feat:continue
   examined+=1
   group=re.search(r'\(([IVX]+)\)',feat)
   # Absence of a Roman-numeral marker denotes QAC's Form I (not absence of evidence).
   form_class=group.group(1) if group else 'I'
   v['verbs'].append({'source_line':n,'seg':int(seg),'surface':form,'features':feat,'root':feature_value(feat,'ROOT'),'lemma':feature_value(feat,'LEM'),'form_class':form_class,'tense':verb_info(feat),'voice':'PASSIVE' if '|PASS' in feat else 'ACTIVE'})
 return grouped,examined

def write_csv(path,fields,records):
 with path.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(records)

def build(masaq,qac_path,out,strict=True):
 out.mkdir(parents=True,exist_ok=True)
 ms_sha=digest(masaq); q_sha=digest(qac_path)
 if strict and (masaq.stat().st_size!=MASAQ_LENGTH or ms_sha!=MASAQ_SHA256):raise ValueError('MASAQ_REFERENCE_FINGERPRINT_MISMATCH')
 if strict and q_sha!=QAC_SHA256:raise ValueError('QAC_REFERENCE_FINGERPRINT_MISMATCH')
 qac,total_qac=load_qac(qac_path)
 grouped=collections.defaultdict(list);masaq_count=0;source_verbs=0
 with masaq.open(encoding='utf-8-sig',newline='') as f:
  rdr=csv.DictReader(f);fields=rdr.fieldnames
  if len(fields)!=19 or not {'Column5','Word_No','Morph_type','Morph_tag','Segmented_Word'}.issubset(fields):raise ValueError('MASAQ_HEADER_INVALID')
  for n,r in enumerate(rdr,1):
   if None in r:raise ValueError('MALFORMED_MASAQ_ROW '+str(n))
   r['MASAQ_Source_Row']=str(n)
   if r['Morph_type']=='Stem' and r['Morph_tag'] in VOCAB:source_verbs+=1
   grouped[(int(r['Sura_No']),int(r['Verse_No']),int(r['Column5']))].append(r)
   masaq_count+=1
 selected=[];excluded=[];residuals=[];counts=collections.Counter();root_counts=collections.Counter();q_form_counts=collections.Counter();tag_counts=collections.Counter()
 # Only original QAC verb entries participate; each is matched at most once.
 for key,obj in qac.items():
  vv=obj['verbs']
  if not vv:continue
  ms=grouped.get(key,[])
  qword=bw_arabic(''.join(s for _,s in sorted(obj['parts'])))
  for v in vv:
   root=v['root'];q_form_counts[v['form_class']]+=1
   if v['form_class']!='I':counts['EXCLUDED_AUGMENTED_QAC_VERBS']+=1;continue
   if not ms:
    residuals.append(dict(Sura_No=key[0],Verse_No=key[1],Column5=key[2],RootBW=root,QAC_Word=qword,QAC_Stem=bw_arabic(v['surface']),Reason='MISSING_MASAQ_WORD',QAC_Line=v['source_line']));continue
   if bare(ms[0]['Word'])!=bare(qword):
    residuals.append(dict(Sura_No=key[0],Verse_No=key[1],Column5=key[2],MASAQ_Word=ms[0]['Word'],QAC_Word=qword,RootBW=root,Reason='WORD_OR_ORTHOGRAPHY_MISMATCH',QAC_Line=v['source_line']));continue
   stems=[r for r in ms if r['Morph_type']=='Stem' and r['Morph_tag'] in VOCAB]
   matched=[r for r in stems if VOCAB[r['Morph_tag']]==(v['tense'],v['voice'])]
   if len(matched)!=1:
    residuals.append(dict(Sura_No=key[0],Verse_No=key[1],Column5=key[2],MASAQ_Word=ms[0]['Word'],QAC_Word=qword,RootBW=root,Reason='UNIQUE_TENSE_VOICE_ALIGNMENT_NOT_PROVEN',QAC_Line=v['source_line']));continue
   r=matched[0]
   # If the word contains multiple verb stems, require a unique exact stem-surface.
   if len(stems)>1 and bare(r['Segmented_Word'])!=bare(bw_arabic(v['surface'])):
    residuals.append(dict(Sura_No=key[0],Verse_No=key[1],Column5=key[2],MASAQ_Word=ms[0]['Word'],QAC_Word=qword,MASAQ_Stem=r['Segmented_Word'],QAC_Stem=bw_arabic(v['surface']),RootBW=root,Reason='MULTIPLE_STEMS_WITHOUT_STEM_SURFACE_MATCH',QAC_Line=v['source_line']));continue
   # Require one of the lexically reviewed Form-I lemmas, NEVER only the root's existence.
   if root not in INTRANSITIVE:
    excluded.append(dict(Sura_No=key[0],Verse_No=key[1],Column5=key[2],MASAQ_Source_Row=r['MASAQ_Source_Row'],Word=r['Word'],Segmented_Word=r['Segmented_Word'],Morph_tag=r['Morph_tag'],QAC_RootBW=root,QAC_Lemma=v['lemma'],QAC_Features=v['features'],Exclusion_Reason='INTRANSITIVITY_UNREVIEWED__NOT_PROVEN_TRANSITIVE',QAC_Line=v['source_line']))
    counts['UNREVIEWED_FORM_I']+=1;continue
   h,detail=health(root)
   if h=='UNRESOLVED':
    residuals.append(dict(Sura_No=key[0],Verse_No=key[1],Column5=key[2],MASAQ_Word=ms[0]['Word'],QAC_Word=qword,RootBW=root,Reason='ROOT_HEALTH_UNRESOLVED',QAC_Line=v['source_line']));continue
   rec={k:r.get(k,'') for k in FIELDS}
   rec.update({'QAC_Form':bw_arabic(v['surface']),'QAC_Lemma':bw_arabic(v['lemma']),'QAC_RootBW':root,'Root_Arabic':INTRANSITIVE[root][0], 'Lexical_Intransitive_Anchor':INTRANSITIVE[root][1],'Verb_Form':'I / الثلاثي المجرد','Verb_Tense':v['tense'],'Verb_Voice':v['voice'],'Root_Health':h,'Root_Health_Detail':detail,'QAC_Features':v['features'],'QAC_Line':v['source_line'],'Evidence_Rank':'ATTESTED_FORM_I_AND_LEXICALLY_PRELIMINARY_INTRANSITIVE','Residual':'INTRANSITIVITY_SENSE_NOT_INDEPENDENTLY_CERTIFIED; PASSIVE_WHEN_ATTESTED_DOES_NOT_PROVE_GENERAL_PRODUCTIVITY','QAC_URL':f'https://corpus.quran.com/wordmorphology.jsp?location=({key[0]}:{key[1]}:{key[2]}:{v["seg"]})'})
   selected.append(rec);counts[(v['tense'],v['voice'])]+=1;root_counts[root]+=1;tag_counts[r['Morph_tag']]+=1
 selected.sort(key=lambda r:int(r['MASAQ_Source_Row']))
 for kind,fname in FILE_FOR.items():write_csv(out/fname,FIELDS,[r for r in selected if (r['Verb_Tense'],r['Verb_Voice'])==kind])
 write_csv(out/'00_All_Mujarrad_Lazim.csv',FIELDS,selected)
 write_csv(out/'06_Excluded_Unreviewed_Form_I.csv',EXFIELDS,excluded)
 write_csv(out/'07_Alignment_Residuals.csv',REFIELDS,residuals)
 passive_candidates={str(v['source_line']):v for obj in qac.values() for v in obj['verbs'] if v['voice']=='PASSIVE' and v['form_class']=='I' and v['root'] in INTRANSITIVE}
 passive_review=[]
 for residual in residuals:
  v=passive_candidates.get(str(residual['QAC_Line']))
  if v is None:continue
  key=(int(residual['Sura_No']),int(residual['Verse_No']),int(residual['Column5']))
  masaq_tags=';'.join(x['Morph_tag'] for x in grouped.get(key,[]) if x['Morph_type']=='Stem')
  passive_review.append({'Sura_No':key[0],'Verse_No':key[1],'Column5':key[2],
   'MASAQ_Word':residual.get('MASAQ_Word',''),'QAC_Word':residual.get('QAC_Word',''),
   'RootBW':v['root'],'RootArabic':INTRANSITIVE[v['root']][0],
   'QAC_Tense':v['tense'],'QAC_Voice':v['voice'],'QAC_Features':v['features'],
   'MASAQ_Stem_Tags':masaq_tags,'QAC_Line':v['source_line'],
   'Review_Reason':residual['Reason'],'Status':'DEFERRED_NO_TWO_SOURCE_AGREEMENT'})
 review_headers=['Sura_No','Verse_No','Column5','MASAQ_Word','QAC_Word','RootBW','RootArabic','QAC_Tense','QAC_Voice','QAC_Features','MASAQ_Stem_Tags','QAC_Line','Review_Reason','Status']
 write_csv(out/'10_Passive_Review.csv',review_headers,passive_review)
 forms=collections.defaultdict(lambda:collections.Counter())
 for r in selected:forms[r['QAC_RootBW']][f"{r['Verb_Tense']}:{r['Verb_Voice']}:{r['Root_Health']}"]+=1
 fam=[]
 for root,co in sorted(forms.items()):
  h,det=health(root)
  fam.append({'RootBW':root,'RootArabic':INTRANSITIVE[root][0],'LexicalAnchor':INTRANSITIVE[root][1],'Health':h,'HealthDetail':det,'ObservedOccurrences':sum(co.values()),'ObservedCategoriesJSON':json.dumps(co,ensure_ascii=False,sort_keys=True),'TransitivityRank':'PRELIMINARY_LEXICAL_CLASSIFICATION__NOT_ALL_SENSES'})
 write_csv(out/'08_Root_Family_Summary.csv',list(fam[0]) if fam else ['RootBW'],fam)
 audit={'status':'ATTESTED_FORM_I_ONLY__INTRANSITIVE_PRELIMINARY','source':{'MASAQ_sha256':ms_sha,'MASAQ_bytes':masaq.stat().st_size,'QAC_sha256':q_sha,'QAC_bytes':qac_path.stat().st_size},'MASAQ_all_rows':masaq_count,'MASAQ_verb_stems_all_forms':source_verbs,'QAC_verb_stems_all_forms':total_qac,'QAC_augmented_verb_stems_excluded':counts['EXCLUDED_AUGMENTED_QAC_VERBS'],'QAC_unreviewed_form_I_aligned':counts['UNREVIEWED_FORM_I'],'selected_occurrences':len(selected),'selected_roots':len(fam),'reviewed_root_whitelist_size':len(INTRANSITIVE),'counts_by_tense_voice':{f'{t}:{v}':counts[(t,v)] for t,v in FILE_FOR},'counts_by_health':dict(collections.Counter(r['Root_Health'] for r in selected)),'alignment_residual_count':len(residuals),'passive_review_count':len(passive_review),'limitations':['This is a conservative reviewed-root pilot; not all Quranic intransitive Form-I verbs are asserted enumerated.','The lexical intransitivity labels are preliminary; no direct object frame has been independently verified for every occurrence.','No imperative passive form is manufactured; only the two attested QAC/MASAQ passive tense categories appear.','QAC Form-I classification relies on the absence of explicit derived-form Roman numeral feature; MASAQ tense and voice must agree.','The root-health flag is a property of canonical root consonants, not proof of particular vowel/weak-letter alternation.','Source MASAQ is untouched.'],'citations':{'MASAQ':'Majdi Sawalha, MASAQ; DOI 10.17632/9yvrzxktmr.2; CC BY 3.0','QAC':'Kais Dukes, Quranic Arabic Corpus morphology v0.4; GNU GPL'}}
 (out/'09_Audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 return audit

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--masaq',type=Path,required=True);ap.add_argument('--qac',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--no-strict',action='store_true');args=ap.parse_args()
 print(json.dumps(build(args.masaq,args.qac,args.out,not args.no_strict),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
