#!/usr/bin/env python3
"""Attested Form-I-transitive-root -> augmented-form family index, without causal derivation claims.

Source corpora unchanged. Shared root/form = family co-attestation only, never proof of direct
semantic derivation, historical direction, valency of an augmented form, or jamid status.
"""
from __future__ import annotations
import argparse,collections,csv,hashlib,json,re,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import mujarrad_mutaaddi_base as b

MASDAR_TAGS={'GERUND','GERUND_MEEM','GERUND_INSTANT','GERUND_PROFESSION','GERUND_STATE'}
DERIV_TAGS={'NOUN_ACTIVE_PART','NOUN_PASSIVE_PART','NOUN_TIME_PLACE','NOUN_INSTRUMENT','ADJ_QUALIT','ADJ_INTENS','ADJ_COMP'}
VERB_TAGS=b.VOCAB
FORM_NUM=('II','III','IV','V','VI','VII','VIII','IX','X')
SOURCES=('https://corpus.quran.com/','https://doi.org/10.17632/9yvrzxktmr.2')
FILE_MAP={
 'AUGMENTED_VERB':'01_Augmented_Verbs.csv',
 'AUGMENTED_MASDAR_AGREED':'02_Augmented_Masdars_Agreed.csv',
 'AUGMENTED_MASDAR_REVIEW':'03_Augmented_Masdars_Review.csv',
 'AUGMENTED_PARTICIPLE_AGREED':'04_Augmented_Nominal_Derivatives.csv',
 'AUGMENTED_DERIVATIVE_REVIEW':'05_Augmented_Nominal_Review.csv',
 'AUGMENTED_NOMINAL_UNCLASSIFIED':'06_Other_Augmented_Nominals_Review.csv',
}
FIELDS=['Sura_No','Verse_No','Column5','Segment_No','MASAQ_Source_Row','MASAQ_Word','MASAQ_Segment','MASAQ_Tag','QAC_Segment','QAC_Tag','QAC_Lemma_BW','QAC_Lemma_Arabic','RootBW','RootArabic','Form','QAC_Features','Morph_Class','Verb_Tense','Verb_Voice','Nominal_Kind','MASAQ_QAC_Agreement','Evidence_Rank','Origin_Form_I_Past','Origin_Past_First','Origin_Past_Occurrences','Origin_Transitivity_Frame_Hint','Root_Health','Root_Health_Detail','Origin_Masdar_Status','Direct_Derivation','Augmented_Transitivity_Status','Residual','QAC_Line','QAC_URL','MASAQ_URL']
REVIEW_FIELDS=['Sura_No','Verse_No','Column5','Segment_No','MASAQ_Source_Row','MASAQ_Word','QAC_Word','MASAQ_Segment','MASAQ_Tag','QAC_Segment','QAC_Tag','RootBW','Form','QAC_Features','QAC_Line','Reason']
FAMILY_FIELDS=['RootBW','RootArabic','Origin_Form_I_Past','Origin_Past_Occurrences','Origin_Past_First','Origin_Transitivity_Frame_Hint','Root_Health','Root_Health_Detail','Form','QAC_Lemma_BW','QAC_Lemma_Arabic','Morph_Class','MASAQ_QAC_Agreement','Occurrence_Count','First_Location','MASAQ_Example','Origin_Masdar_Status','Link_Type','Direct_Derivation','Augmented_Transitivity_Status']
ORIGIN_FIELDS=['RootBW','RootArabic','Origin_Form_I_Past','Origin_Past_Occurrences','Origin_Past_First','Origin_Transitivity_Frame_Hint','Origin_Masdar_Two_Source_Count','Origin_Masdar_Review_Count','Origin_Masdar_Lemmas','Jamid_Status','Status_Explanation']
EXCLUDED_FIELDS=['RootBW','RootArabic','Lazim_Past','Eligible_Transitive_Origin','Form','QAC_Tag','QAC_Features','Sura_No','Verse_No','Column5','QAC_Line','Reason']

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,fieldnames,records):
 with path.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fieldnames,extrasaction='ignore');w.writeheader();w.writerows(records)
def readcsv(path):
 with path.open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
def keyloc(k):return ':'.join(map(str,k))
def origin_load(past,strict=True):
 rows=readcsv(past)
 out=collections.defaultdict(list)
 for r in rows:
  if (r['Verb_Form'],r['Verb_Tense'],r['Verb_Voice'])!=('I / الثلاثي المجرد','PAST','ACTIVE'):raise ValueError('ORIGIN_NOT_FORM_I_PAST_ACTIVE')
  if strict and r['QAC_RootBW'] not in b.TRANSITIVE:raise ValueError('UNLICENSED_ORIGIN')
  out[r['QAC_RootBW']].append(r)
 return out

def masaq_words(p):
 grouped=collections.defaultdict(list);n=0
 with p.open(encoding='utf-8-sig',newline='') as f:
  rr=csv.DictReader(f)
  if len(rr.fieldnames)!=19:raise ValueError('MASAQ_19_COLUMNS_REQUIRED')
  for n,row in enumerate(rr,1):
   if None in row:raise ValueError('INVALID_MASAQ_RECORD')
   row['MASAQ_Source_Row']=str(n)
   grouped[(int(row['Sura_No']),int(row['Verse_No']),int(row['Column5']))].append(row)
 return grouped,n

def qac_words(p,elig,lazim):
 obj=collections.defaultdict(lambda:{'parts':[],'targets':[]});excluded=[];allroots=collections.Counter()
 with p.open(encoding='utf-8-sig') as f:
  for n,line in enumerate(f,1):
   m=b.LOC.match(line)
   if not m:continue
   su,ay,wo,sg,surface,tag,feat=m.groups();k=(int(su),int(ay),int(wo))
   root=b.feature_value(feat,'ROOT')
   fnum=re.search(r'\(([IVX]+)\)',feat)
   if not fnum or not feat.startswith('STEM|'):continue
   form=fnum.group(1)
   if form not in FORM_NUM:continue
   if root not in elig and root not in lazim:continue
   if root in lazim and root not in elig:
    # Retain only witnessed augmented forms under an excluded intransitive origin,
    # rather than mistakenly treating all nouns with same root as an eligible source.
    excluded.append(dict(RootBW=root,RootArabic=lazim[root][0]['Root_Arabic'],Lazim_Past=lazim[root][0]['Lexical_Intransitive_Anchor'] if 'Lexical_Intransitive_Anchor' in lazim[root][0] else lazim[root][0].get('Lexical_Lazim_Anchor',''),Eligible_Transitive_Origin='NO',Form=form,QAC_Tag=tag,QAC_Features=feat,Sura_No=su,Verse_No=ay,Column5=wo,QAC_Line=n,Reason='FORM_I_ORIGIN_IN_PRIOR_LAZIM_PILOT__OUT_OF_SCOPE'))
    continue
   if tag!='V' and tag not in {'N','ADJ'}:continue
   val=obj[k]; val['targets'].append(dict(seg=int(sg),surface=surface,tag=tag,features=feat,root=root,form=form,lemma=b.feature_value(feat,'LEM'),line=n))
   allroots[(root,form)]+=1
 # only query all segments for candidate word positions - second QAC scan bounds memory
 with p.open(encoding='utf-8-sig') as f:
  for line in f:
   m=b.LOC.match(line)
   if not m:continue
   su,ay,wo,sg,surface,tag,feat=m.groups();k=(int(su),int(ay),int(wo))
   if k in obj:obj[k]['parts'].append((int(sg),surface))
 return obj,excluded,allroots

def build(masaq,qac,past,origin_strict,origin_candidates,lazim_past,out,strict=True):
 out.mkdir(parents=True,exist_ok=True)
 dig={k:sha(v) for k,v in [('MASAQ',masaq),('QAC',qac),('PAST_TRANSITIVE',past),('ORIGIN_STRICT',origin_strict),('ORIGIN_CANDIDATES',origin_candidates),('PAST_LAZIM',lazim_past)]}
 if strict and (dig['MASAQ']!=b.MASAQ_SHA256 or masaq.stat().st_size!=b.MASAQ_LENGTH):raise ValueError('MASAQ_REFERENCE_SHA_OR_SIZE_MISMATCH')
 if strict and dig['QAC']!=b.QAC_SHA256:raise ValueError('QAC_REFERENCE_SHA_MISMATCH')
 origins=origin_load(past,strict)
 lazim=collections.defaultdict(list)
 for x in readcsv(lazim_past):lazim[x['QAC_RootBW']].append(x)
 if set(origins)&set(lazim):raise ValueError('TRANSITIVE_LAZIM_ORIGINS_OVERLAP__SENSE_REVIEW_REQUIRED')
 strict_m=collections.defaultdict(list);cand_m=collections.defaultdict(list)
 for r in readcsv(origin_strict):
  if r['QAC_RootBW'] in origins and r['QAC_VN_Form']=='I':strict_m[r['QAC_RootBW']].append(r)
 for r in readcsv(origin_candidates):
  if r['QAC_RootBW'] in origins and not r['QAC_Derived_Form']:cand_m[r['QAC_RootBW']].append(r)
 mword,mscount=masaq_words(masaq)
 qwords,lazim_exclusions,raw_counts=qac_words(qac,origins,lazim)
 outputs=collections.defaultdict(list);reviews=[];seen=set();unmatched=collections.Counter()
 for k,obj in sorted(qwords.items()):
  qword=b.bw_arabic(''.join(s for _,s in sorted(obj['parts'])))
  ms=mword.get(k,[]);ms_stems=[r for r in ms if r['Morph_type']=='Stem']
  for v in obj['targets']:
   rroot=v['root'];typ='VERB' if v['tag']=='V' else 'VN' if '|VN' in v['features'] else 'PARTICIPLE' if '|PCPL' in v['features'] else 'OTHER_NOMINAL'
   expected=(b.verb_info(v['features']),'PASSIVE' if '|PASS' in v['features'] else 'ACTIVE')
   rlist=[r for r in ms_stems if r['Morph_tag'] in VERB_TAGS and b.VOCAB[r['Morph_tag']]==expected] if typ=='VERB' else [r for r in ms_stems if r['Morph_tag'] in MASDAR_TAGS|DERIV_TAGS|{'NOUN_ABSTRACT','NOUN_CONCRETE','NOUN_PROP'}]
   if not ms or b.bare(ms[0]['Word'])!=b.bare(qword):
    reason='NO_MASAQ_WORD' if not ms else 'WORD_OR_ORTHOGRAPHY_MISMATCH'
    reviews.append(dict(Sura_No=k[0],Verse_No=k[1],Column5=k[2],Segment_No=v['seg'],MASAQ_Word=ms[0]['Word'] if ms else '',QAC_Word=qword,QAC_Segment=b.bw_arabic(v['surface']),QAC_Tag=v['tag'],RootBW=rroot,Form=v['form'],QAC_Features=v['features'],QAC_Line=v['line'],Reason=reason));continue
   if not rlist:
    reviews.append(dict(Sura_No=k[0],Verse_No=k[1],Column5=k[2],Segment_No=v['seg'],MASAQ_Word=ms[0]['Word'],QAC_Word=qword,QAC_Segment=b.bw_arabic(v['surface']),QAC_Tag=v['tag'],RootBW=rroot,Form=v['form'],QAC_Features=v['features'],QAC_Line=v['line'],Reason='MISSING_COMPATIBLE_MASAQ_STEM'));continue
   # Exact stem comparison is mandatory for multiple candidates and when the QAC
   # word contains more than one target stem; no ambiguous attribution.
   if len(rlist)!=1 or len(obj['targets'])>1:
    matches=[r for r in rlist if b.bare(r['Segmented_Word'])==b.bare(b.bw_arabic(v['surface']))]
    if len(matches)!=1:
     reviews.append(dict(Sura_No=k[0],Verse_No=k[1],Column5=k[2],Segment_No=v['seg'],MASAQ_Word=ms[0]['Word'],QAC_Word=qword,QAC_Segment=b.bw_arabic(v['surface']),QAC_Tag=v['tag'],RootBW=rroot,Form=v['form'],QAC_Features=v['features'],QAC_Line=v['line'],Reason='NON_UNIQUE_STEM_ALIGNMENT'));continue
    r=matches[0]
   else:r=rlist[0]
   proof=(r['MASAQ_Source_Row'],v['line'])
   if proof in seen:raise ValueError('DUPLICATE_MASAQ_QAC_WITNESS')
   seen.add(proof)
   if typ=='VERB':
    if r['Morph_tag'] not in VERB_TAGS or b.VOCAB[r['Morph_tag']]!=expected:raise ValueError('VERB_AGREEMENT_BYPASS')
    cat='AUGMENTED_VERB';agreement='MASAQ_TENSE_VOICE_AND_QAC_AGREE';evidence='TWO_SOURCE_AUGMENTED_VERB'
   elif typ=='VN':
    if r['Morph_tag']=='GERUND':cat='AUGMENTED_MASDAR_AGREED';agreement='MASAQ_GERUND_AND_QAC_VN_AGREE';evidence='TWO_SOURCE_AUGMENTED_VN'
    else:cat='AUGMENTED_MASDAR_REVIEW';agreement='MASAQ_TAG_DIFFERS_FROM_QAC_VN';evidence='QAC_VN_ONLY_OR_MASAQ_SUBTYPE_UNREVIEWED'
   elif typ=='PARTICIPLE':
    kind='NOUN_ACTIVE_PART' if '|ACT|PCPL' in v['features'] else 'NOUN_PASSIVE_PART' if '|PASS|PCPL' in v['features'] else ''
    if r['Morph_tag']==kind and kind:cat='AUGMENTED_PARTICIPLE_AGREED';agreement='MASAQ_AND_QAC_PARTICIPLE_AGREE';evidence='TWO_SOURCE_AUGMENTED_PCPL'
    else:cat='AUGMENTED_DERIVATIVE_REVIEW';agreement='PARTICIPLE_TAG_MISMATCH';evidence='QAC_PCPL_ONLY'
   else:cat='AUGMENTED_NOMINAL_UNCLASSIFIED';agreement='AUGMENTED_FORM_MARKER_BUT_NO_VN_PCPL';evidence='QAC_AUGMENTED_NOMINAL_TAG_ONLY'
   anchor=origins[rroot];h,healthdet=b.health(rroot)
   base_m='FORM_I_SOURCE_TWO_SOURCE_ATTESTED' if strict_m[rroot] else 'FORM_I_SOURCE_CANDIDATE_ONLY' if cand_m[rroot] else 'FORM_I_SOURCE_NOT_ATTESTED_IN_PILOT'
   residual='FORM_I_TRANSITIVITY_PRELIMINARY; SAME_ROOT_AND_FORM_DO_NOT_PROVE_DIRECT_DERIVATION_OR_AUGMENTED_TRANSITIVITY; MASDAR_JAMID_NOT_PROVEN'
   row=dict(Sura_No=k[0],Verse_No=k[1],Column5=k[2],Segment_No=v['seg'],MASAQ_Source_Row=r['MASAQ_Source_Row'],MASAQ_Word=r['Word'],MASAQ_Segment=r['Segmented_Word'],MASAQ_Tag=r['Morph_tag'],QAC_Segment=b.bw_arabic(v['surface']),QAC_Tag=v['tag'],QAC_Lemma_BW=v['lemma'],QAC_Lemma_Arabic=b.bw_arabic(v['lemma']),RootBW=rroot,RootArabic=b.TRANSITIVE[rroot][0],Form=v['form'],QAC_Features=v['features'],Morph_Class=cat,Verb_Tense=expected[0] if typ=='VERB' else '',Verb_Voice=expected[1] if typ=='VERB' else '',Nominal_Kind=('VN' if typ=='VN' else 'ACT_PCPL' if typ=='PARTICIPLE' and '|ACT|PCPL' in v['features'] else 'PASS_PCPL' if typ=='PARTICIPLE' and '|PASS|PCPL' in v['features'] else 'UNCLASSIFIED' if typ!='VERB' else ''),MASAQ_QAC_Agreement=agreement,Evidence_Rank=evidence,Origin_Form_I_Past=b.TRANSITIVE[rroot][1],Origin_Past_First=keyloc((anchor[0]['Sura_No'],anchor[0]['Verse_No'],anchor[0]['Column5'])),Origin_Past_Occurrences=len(anchor),Origin_Transitivity_Frame_Hint=b.TRANSITIVE[rroot][2],Root_Health=h,Root_Health_Detail=healthdet,Origin_Masdar_Status=base_m,Direct_Derivation='NOT_PROVEN',Augmented_Transitivity_Status='NOT_ASSESSED__ORIGIN_IS_PRELIMINARY_TRANSITIVE',Residual=residual,QAC_Line=v['line'],QAC_URL=f'https://corpus.quran.com/wordmorphology.jsp?location=({k[0]}:{k[1]}:{k[2]}:{v["seg"]})',MASAQ_URL='https://doi.org/10.17632/9yvrzxktmr.2')
   outputs[cat].append(row)
 for cat,filename in FILE_MAP.items():write(out/filename,FIELDS,outputs[cat])
 allrows=[x for cat in FILE_MAP for x in outputs[cat]]
 write(out/'00_All_Augmented_Root_Links.csv',FIELDS,allrows)
 write(out/'10_Alignment_Residuals.csv',REVIEW_FIELDS,reviews)
 write(out/'11_Excluded_Lazim_Origin.csv',EXCLUDED_FIELDS,lazim_exclusions)
 origrows=[]
 for rt,anchor in sorted(origins.items()):
  lm=sorted({(x['QAC_Lemma_BW'],x['QAC_Lemma_Arabic']) for x in strict_m[rt]})
  origrows.append(dict(RootBW=rt,RootArabic=b.TRANSITIVE[rt][0],Origin_Form_I_Past=b.TRANSITIVE[rt][1],Origin_Past_Occurrences=len(anchor),Origin_Past_First=keyloc((anchor[0]['Sura_No'],anchor[0]['Verse_No'],anchor[0]['Column5'])),Origin_Transitivity_Frame_Hint=b.TRANSITIVE[rt][2],Origin_Masdar_Two_Source_Count=len(strict_m[rt]),Origin_Masdar_Review_Count=len(cand_m[rt]),Origin_Masdar_Lemmas=';'.join(a for _,a in lm),Jamid_Status='UNASSESSED__MASDAR_NOT_AUTOMATICALLY_JAMID',Status_Explanation='Form-I verbal noun is an origin-level morphological relation, not an independently evidenced lexical jamid classification.'))
 write(out/'07_Form_I_Transitive_Origins.csv',ORIGIN_FIELDS,origrows)
 origin_fields=FIELDS+['Origin_Masdar_Classification']
 origins_m=[]
 for cat,subset in [('FORM_I_MASDAR_TWO_SOURCE',strict_m),('FORM_I_MASDAR_REVIEW',cand_m)]:
  for rt,rr in sorted(subset.items()):
   for r in rr:
    origins_m.append({**{f:'' for f in FIELDS},**dict(Sura_No=r['Sura_No'],Verse_No=r['Verse_No'],Column5=r['Column5'],MASAQ_Source_Row=r['MASAQ_Source_Row'],MASAQ_Word=r['MASAQ_Word'],MASAQ_Segment=r['MASAQ_Segment'],MASAQ_Tag=r['MASAQ_Tag'],QAC_Segment=r['QAC_Segment'],QAC_Tag=r['QAC_Tag'],QAC_Lemma_BW=r['QAC_Lemma_BW'],QAC_Lemma_Arabic=r['QAC_Lemma_Arabic'],RootBW=rt,RootArabic=r['Root_Arabic'],Form='I',QAC_Features=r['QAC_Features'],Origin_Form_I_Past=r['Lexical_Past_Anchor'],Root_Health=r['Root_Health'],Root_Health_Detail=r['Root_Health_Detail'],Origin_Masdar_Status=cat,Direct_Derivation='NOT_PROVEN',Residual='NO_LEXICAL_JAMID_PROOF; SENSE_SPECIFIC_LINK_NOT_PROVEN',QAC_Line=r['QAC_Line'],QAC_URL=r['QAC_URL'],Origin_Masdar_Classification='NOT_PROVEN_JAMID')})
 write(out/'08_Origin_Form_I_Masdars.csv',origin_fields,origins_m)
 # Family relation: group by QAC (root, form, lexeme) rather than multiplying verb and noun rows.
 lex=collections.defaultdict(list)
 for x in allrows:lex[(x['RootBW'],x['Form'],x['QAC_Lemma_BW'],x['Morph_Class'],x['MASAQ_QAC_Agreement'])].append(x)
 fam=[]
 for (rt,form,lemma,cat,agree),rr in sorted(lex.items()):
  x=rr[0]
  fam.append(dict(RootBW=rt,RootArabic=x['RootArabic'],Origin_Form_I_Past=x['Origin_Form_I_Past'],Origin_Past_Occurrences=x['Origin_Past_Occurrences'],Origin_Past_First=x['Origin_Past_First'],Origin_Transitivity_Frame_Hint=x['Origin_Transitivity_Frame_Hint'],Root_Health=x['Root_Health'],Root_Health_Detail=x['Root_Health_Detail'],Form=form,QAC_Lemma_BW=lemma,QAC_Lemma_Arabic=x['QAC_Lemma_Arabic'],Morph_Class=cat,MASAQ_QAC_Agreement=agree,Occurrence_Count=len(rr),First_Location=keyloc((x['Sura_No'],x['Verse_No'],x['Column5'])),MASAQ_Example=x['MASAQ_Word'],Origin_Masdar_Status=x['Origin_Masdar_Status'],Link_Type='ROOT_PLUS_AUGMENTED_FORM_CO_ATTESTATION',Direct_Derivation='NOT_PROVEN',Augmented_Transitivity_Status='NOT_ASSESSED'))
 write(out/'09_Family_Relations.csv',FAMILY_FIELDS,fam)
 counts={x:len(outputs[x]) for x in FILE_MAP}
 audit=dict(status='ATTESTED_AUGMENTED_FORMS_ON_PRELIMINARY_FORM_I_TRANSITIVE_ROOTS__NOT_DERIVATIONAL_PROOF',source_sha256=dig,source_MASAQ_records=mscount,origin_form_I_past_occurrences=sum(map(len,origins.values())),origin_form_I_transitive_roots=len(origins),origin_lazim_roots_excluded=len(lazim),original_lazim_overlap_count=0,qac_augmented_target_segments=sum(raw_counts.values()),categories=counts,all_matched_links=len(allrows),matched_form_counts=dict(sorted(collections.Counter(x['Form'] for x in allrows).items())),family_relation_groups=len(fam),two_source_origin_masdar_occurrences=len([r for r in origins_m if r['Origin_Masdar_Status']=='FORM_I_MASDAR_TWO_SOURCE']),origin_masdar_candidates=len([r for r in origins_m if r['Origin_Masdar_Status']=='FORM_I_MASDAR_REVIEW']),alignment_residual_count=len(reviews),excluded_lazim_augmented_segments=len(lazim_exclusions),nominal_jamid_certificates_issued=0,direct_derivation_certificates_issued=0,augmented_verb_transitivity_certificates_issued=0,source_urls=list(SOURCES),guards=['Do not infer that augmented verb is transitive because its Form-I origin has a preliminary transitive frame.','No immediate causal or semantic derivation from common root and form.','Origin masdar is not automatically jamid.','Form-I masdars are context/lexeme linked and independent origin proofs remain pending.','QAC VN and participle require MASAQ matching tag for agreed outputs.','No inferred/unattested masdar or participle is entered.','Only QAC explicitly marked Roman numerals II-X are eligible as augmented.','Lazim origin roots from earlier pilot remain out of scope.','MASAQ and QAC are not modified.','QAC and MASAQ redistribution obligations must be observed.'])
 (out/'12_Audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 return audit

def cli():
 p=argparse.ArgumentParser(description=__doc__)
 for name in ('masaq','qac','past','origin-strict','origin-candidates','lazim-past','out'):p.add_argument('--'+name,type=Path,required=True)
 p.add_argument('--no-strict',action='store_true');a=p.parse_args()
 v=build(a.masaq,a.qac,a.past,a.origin_strict,a.origin_candidates,a.lazim_past,a.out,not a.no_strict)
 print(json.dumps({k:v[k] for k in ('origin_form_I_transitive_roots','origin_form_I_past_occurrences','qac_augmented_target_segments','all_matched_links','categories','alignment_residual_count','excluded_lazim_augmented_segments','family_relation_groups')},ensure_ascii=False,indent=2))
if __name__=='__main__':cli()
