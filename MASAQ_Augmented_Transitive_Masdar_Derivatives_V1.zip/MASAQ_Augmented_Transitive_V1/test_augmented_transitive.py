#!/usr/bin/env python3
"""Consistency tests over actual bounded derived outputs (no fabricated fixtures)."""
import collections,csv,hashlib,json,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
COUNTS={'01_Augmented_Verbs.csv':454,'02_Augmented_Masdars_Agreed.csv':8,'03_Augmented_Masdars_Review.csv':8,'04_Augmented_Nominal_Derivatives.csv':44,'05_Augmented_Nominal_Review.csv':2,'06_Other_Augmented_Nominals_Review.csv':0}
def rows(name):
 with (HERE/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
class RealSourceAuditTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.audit=json.loads((HERE/'12_Audit.json').read_text(encoding='utf-8'));cls.rows=rows('00_All_Augmented_Root_Links.csv')
 def test_counts_reproduced(self):
  self.assertEqual({name:len(rows(name)) for name in COUNTS},COUNTS)
 def test_total_and_partition(self):
  self.assertEqual(len(self.rows),516)
  self.assertEqual(sum(COUNTS.values()),516)
 def test_no_duplicate_qac_witness(self):
  q=[x['QAC_Line'] for x in self.rows];self.assertEqual(len(q),len(set(q)))
 def test_only_attested_augmented_forms(self):
  self.assertTrue(all(x['Form'] in ('II','III','IV','V','VI','VII','VIII','IX','X') and '|('+x['Form']+')' in x['QAC_Features'] for x in self.rows))
 def test_roots_bounded_by_prior_past(self):
  rr={x['RootBW'] for x in rows('07_Form_I_Transitive_Origins.csv')}
  self.assertEqual(len(rr),30)
  self.assertTrue({x['RootBW'] for x in self.rows}<=rr)
 def test_no_lazim_overlap(self):
  self.assertEqual(self.audit['original_lazim_overlap_count'],0)
  self.assertTrue(all(x['RootBW'] not in {z['RootBW'] for z in rows('11_Excluded_Lazim_Origin.csv')} for x in self.rows))
 def test_categories_are_correct(self):
  for cat,name in [('AUGMENTED_VERB','01_Augmented_Verbs.csv'),('AUGMENTED_MASDAR_AGREED','02_Augmented_Masdars_Agreed.csv'),('AUGMENTED_MASDAR_REVIEW','03_Augmented_Masdars_Review.csv'),('AUGMENTED_PARTICIPLE_AGREED','04_Augmented_Nominal_Derivatives.csv'),('AUGMENTED_DERIVATIVE_REVIEW','05_Augmented_Nominal_Review.csv')]:
   self.assertTrue(all(x['Morph_Class']==cat for x in rows(name)))
 def test_strict_masdars(self):
  self.assertTrue(all('|VN|' in x['QAC_Features'] and x['MASAQ_Tag']=='GERUND' for x in rows('02_Augmented_Masdars_Agreed.csv')))
 def test_strict_participles(self):
  self.assertTrue(all('|PCPL|' in x['QAC_Features'] and x['MASAQ_Tag']==('NOUN_ACTIVE_PART' if '|ACT|PCPL' in x['QAC_Features'] else 'NOUN_PASSIVE_PART') for x in rows('04_Augmented_Nominal_Derivatives.csv')))
 def test_original_masdar_no_automatic_jamid(self):
  self.assertTrue(all(x['Jamid_Status']=='UNASSESSED__MASDAR_NOT_AUTOMATICALLY_JAMID' for x in rows('07_Form_I_Transitive_Origins.csv')))
  self.assertTrue(all(x['Origin_Masdar_Classification']=='NOT_PROVEN_JAMID' for x in rows('08_Origin_Form_I_Masdars.csv')))
 def test_no_direct_derivation_or_augmented_valency_claim(self):
  self.assertTrue(all(x['Direct_Derivation']=='NOT_PROVEN' and x['Augmented_Transitivity_Status'].startswith('NOT_ASSESSED') for x in self.rows))
 def test_audit_integrity(self):
  self.assertEqual(self.audit['all_matched_links'],len(self.rows))
  self.assertEqual(self.audit['alignment_residual_count'],len(rows('10_Alignment_Residuals.csv')))
  self.assertEqual(self.audit['family_relation_groups'],len(rows('09_Family_Relations.csv')))
 def test_source_fingerprints_in_audit(self):
  self.assertEqual(self.audit['source_sha256']['MASAQ'],'d43d2a813afbe0490254bb26623d6041ed352a273d333e731ddbcda3bd0b6f3a')
  self.assertEqual(self.audit['source_sha256']['QAC'],'a1d12923815341face765083805d2148ed2d9f5cc3f7d6665219d887675d8c46')
 def test_links_no_unsupported_jamid(self):
  self.assertEqual(self.audit['nominal_jamid_certificates_issued'],0)
  self.assertEqual(self.audit['direct_derivation_certificates_issued'],0)
 def test_other_pilot_lazim_excluded(self):
  self.assertEqual(self.audit['excluded_lazim_augmented_segments'],len(rows('11_Excluded_Lazim_Origin.csv')))
if __name__=='__main__':unittest.main()
